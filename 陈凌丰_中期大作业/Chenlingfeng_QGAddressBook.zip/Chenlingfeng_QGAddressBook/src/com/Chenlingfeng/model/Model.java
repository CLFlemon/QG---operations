package com.Chenlingfeng.model;

public class Model {
	
	public static String id;
	public static String name;
	public static String group;
	public static String grade;
	public static String clas;
	public static String phone;
	public static String email;
	public static String dormitory;
	public static String address;
	//1
	public  String getID() {
		System.out.println(2);
		return id;
	}
	public  void setID(String id) {
		System.out.println(id);
		Model.id = id;
		//System.out.println("Model.id");
	}
	//2
	public   String getName() {
		return name;
	}
	public  void setName(String name) {
		Model.name = name;
	}
	
	public  String getGroup() {
		return group;
	}
	public  void setGroup(String group) {
		Model.group = group;
	}
	//3
	public  String getGrade() {
		return grade;
	}
	public  void setGrade(String grade) {
		Model.grade = grade;
	}
	//4
	public  String getClas() {
		return clas;
	}
	public  void setClas(String clas) {
		Model.clas = clas;
	}
	//5
	public  String getPhone() {
		return phone;
	}
	public  void setPhone(String phone) {
		Model.phone = phone;
	}
	//6
	public static String getEmail() {
		return email;
	}
	public  void setEmail(String email) {
		Model.email = email;
	}
	//7
	public String getDormitory() {
		return dormitory;
	}
	public  void setDormitory(String dormitory) {
		Model.dormitory = dormitory;
	}
	//8
	public  String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		Model.address = address;
	}
	
	

}
