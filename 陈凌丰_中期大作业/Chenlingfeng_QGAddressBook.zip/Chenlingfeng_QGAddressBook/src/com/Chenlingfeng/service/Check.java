package com.Chenlingfeng.service;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import com.Chenlingfeng.dao.*;
import com.Chenlingfeng.model.*;
import com.Chenlingfeng.util.*;
import com.Chenlingfeng.view.*;

public class Check extends JFrame{
	public static void isright(String name,String pwd) {
		System.out.println("1!");
		System.out.println(name);
		System.out.println(pwd);
		logincheck.sqlquery();
		if( logincheck.userword.equals(name) && logincheck.pwd.equals(pwd) )
		{
			JOptionPane.showMessageDialog(null, "��¼�ɹ���","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
			Uifourchoose next = new Uifourchoose();
		}
		else 
		{
			JOptionPane.showMessageDialog(null, "�û��������������","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
		}
	}
}
