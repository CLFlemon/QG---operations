#include<cstdio>
#include<stdlib.h>
#include<time.h>
#include<algorithm>
using namespace std;
int k;
const int maxn = 10000;
const int cutoff = 20;//С�����ò����������Ч
void InsertionSort(int A[], int m)
{
	int j, p;
	int temp;
	for (p = 1; p < m; p++)
	{
		temp = A[p];
		for (j = p; j > 0 && A[j - 1] > temp; j--) A[j] = A[j - 1];//����Ҫ��
		A[j] = temp;
	}
}
int Median3(int A[], int left, int right)
{
	int temp;
	int mid = (left + right) / 2;

	if (A[left] > A[mid]) swap(A[left], A[mid]);
	if (A[left] > A[right]) swap(A[right], A[left]);
	if (A[mid] > A[right]) swap(A[mid], A[right]);
	//�����left<mid<right �������ڷָ�

	swap(A[mid], A[right - 1]);
	return A[right - 1];
}
void qsort(int A[], int left, int right)
{
	int i, j;
	int Pivot;
	if (left + cutoff <= right)
	{
		Pivot = Median3(A, left, right);//ѡ��ŦԪ
		i = left, j = right - 1;
		for (; ;)
		{
			while(A[++i]<Pivot) {}
			while(A[--j]>Pivot) {}//�ָ�
			if (i < j) swap(A[i], A[j]);
			else break;
		}
		swap(A[i], A[right - 1]);
		if (k <= i) qsort(A, left, i - 1);
		else qsort(A, i + 1, right);
	}
	else InsertionSort(A + left, right - left + 1);

}
void Quicksort(int A[], int N)
{
	qsort(A, 0, N - 1);
}

int main()
{
	printf("������ڼ�С:\n");
	scanf("%d", &k);
	clock_t start, finish;
	double duration;
	int a[maxn]; 
	srand((unsigned)time(NULL));
	for (int i = 0; i < maxn; i++) a[i] = rand() % maxn + 1;
	start = clock();
	Quicksort(a, maxn);
	finish = clock();
	printf("%d\n", a[k]);
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	printf("%f second\n", duration);
	return 0;
}