#include<cstdio>
#include<algorithm>
#include<time.h>
using namespace std;
const int maxn = 7;
void fun(int A[])
{
	int left = 0, right = maxn - 1;
	for (int i = left; i <= right;) {
		if (A[i] == 0) {
			swap(A[left], A[i]);
			left++;
			i++;
		}
		else if (A[i] == 2) {
			swap(A[right], A[i]);
			right--;
		}
		else  i++;
	}
}
int main()
{
	srand((unsigned)time(NULL));
	int a[maxn];
	for (int i = 0; i < maxn; i++) a[i] = rand() % 3;
	for (int i = 0; i < maxn; i++) printf("%d ", a[i]);
	printf("\n");
	fun(a);
	for (int i = 0; i < maxn; i++) printf("%d ", a[i]);
	return 0;
}