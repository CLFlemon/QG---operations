#include<cstdio>
#include<stdlib.h>
#include<time.h>
const int maxn = 100000;//�������

void Bsort(int A[], int B[])
{
	for (int i = 0; i < 100; i++)	B[A[i]]++;
}
int main()
{
	int a[maxn];
	int b[maxn + 5];
	clock_t start, finish;
	double duration;//����
	start = clock();
	for (int j = 0; j < maxn; j++)
	{
		srand((unsigned)time(NULL));
		for (int i = 0; i < 100; i++) a[i] = rand() % 100 + 1;
		b[100+ 5] = { 0 };
		Bsort(a, b);
	}
	finish = clock();
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	printf("%f second\n", duration);
	return 0;
}