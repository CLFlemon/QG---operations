#include<cstdio>
#include<stdlib.h>
#include<time.h>
const int maxn = 100000;//ѭ������
void InsertionSort(int a[100], int m )
{
	int j, p;
	int temp;
	for (p = 1; p < m; p++)
	{
		temp = a[p];
		for (j = p; j > 0 && a[j - 1] > temp; j--) a[j] = a[j - 1];//����Ҫ��
		a[j] = temp;
	}
}
int main()
{
	clock_t start, finish;
	double duration;
	int a[100];
	start = clock();
	for (int j = 1; j <= maxn; j++)
	{
		srand((unsigned)time(NULL));
		for (int i = 0; i < 100; i++) a[i] = rand() % 200 + 1;
		InsertionSort(a, 100);
	}
	finish = clock();
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	printf("%f second\n", duration);
	return 0;
}