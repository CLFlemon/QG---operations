#include<cstdio>
#include<stdlib.h>
#include<time.h>
const int maxn = 100000;
void Merge(int A[], int *tmp, int Lpos, int Rpos, int RightEnd)
{
	int i, leftend, numelements, tmppos;
	leftend = Rpos - 1;//
	tmppos = Lpos;
	numelements = RightEnd - Lpos + 1;
	//���濪ʼ�鲢
	while (Lpos <= leftend && Rpos <= RightEnd)
	{
		if (A[Lpos] <= A[Rpos]) tmp[tmppos++] = A[Lpos++];
		else tmp[tmppos++] = A[Rpos++];
	}
	//�ж�����߻����ұ���������һ��ѭ��
	while (Lpos <= leftend) tmp[tmppos++] = A[Lpos++];
	while (Rpos <= RightEnd) tmp[tmppos++] = A[Rpos++];

	for (i = 0; i < numelements; i++, RightEnd--)
		A[RightEnd] = tmp[RightEnd];

}
void Msort(int A[], int *tmp, int left, int right)
{
	int mid;
	if (left < right)
	{
		mid = (left + right) / 2;
		//���濪ʼ�ָ�����
		Msort(A, tmp, left, mid);
		Msort(A, tmp, mid+1, right);
		Merge(A, tmp, left, mid + 1, right);
	}
}
void Mergesort(int A[], int N)
{
	int *tmp;
	tmp = (int *)malloc(sizeof(int)*N);
	if (tmp != NULL)
	{
		Msort(A, tmp, 0, N - 1);//ԭ������ ����Ҫ���ָ��С���� ��� �н�
		free(tmp);
	}
	else printf("���Ӳ�����!\n");//��ȫ�Լ��

}
int main()
{
	clock_t start, finish;
	double duration;
	int a[100];
	start = clock();
	for (int j = 0; j < maxn; j++)
	{
		srand((unsigned)time(NULL));
		for (int i = 0; i < 100; i++) a[i] = rand() % maxn + 1;
		Mergesort(a, 100);
	}
		finish = clock();
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	printf("%f second\n", duration);
	return 0;
}