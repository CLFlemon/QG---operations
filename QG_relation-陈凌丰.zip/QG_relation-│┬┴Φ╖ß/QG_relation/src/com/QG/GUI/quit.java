package com.QG.GUI;

public class quit {

}
